import requests

# Retrieve the list of proxies
proxy_list_url = "https://openproxylist.xyz/socks5.txt"
proxies = requests.get(proxy_list_url).text.strip().split("\n")

# Add the protocol to each proxy address
def add_protocol(proxy_address):
    return "socks5://" + proxy_address

new_proxies = map(add_protocol, proxies)
new_proxies_list = "\n".join(list(new_proxies))

# Write the modified proxy list to a file
with open("s5.txt", "w") as file:
    file.write(new_proxies_list)

print("Successfully downloaded proxies socks5")